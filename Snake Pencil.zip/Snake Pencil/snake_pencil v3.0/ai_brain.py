# ai_brain.py
import math
import random
import datetime


# ============================================================
# LOGGING SYSTEM
# ============================================================

class AILog:
    def __init__(self):
        t = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.path = f"log_{t}.txt"

    def write(self, text):
        with open(self.path, "a") as f:
            f.write(text + "\n")


# ============================================================
# ABSTRACT AI MODES
# ============================================================

class AbstractAIBase:
    def step(self, x, y): raise NotImplementedError


class FlowFieldAI(AbstractAIBase):
    def __init__(self): self.t = 0
    def step(self, x, y):
        self.t += 0.03
        return math.sin(0.01*y + self.t), math.cos(0.01*x + self.t)


class AttractorAI(AbstractAIBase):
    def __init__(self):
        self.a = -1.2
        self.b = 1.7
    def step(self, x, y):
        return (
            math.sin(self.a * y) + 0.8 * math.cos(self.a * x),
            math.sin(self.b * x) + 0.8 * math.cos(self.b * y)
        )


class NoiseAI(AbstractAIBase):
    def __init__(self): self.t = 0
    def step(self, x, y):
        self.t += 0.05
        return (
            math.sin(self.t) + random.uniform(-0.2, 0.2),
            math.cos(self.t) + random.uniform(-0.2, 0.2)
        )


class HybridAI(AbstractAIBase):
    def __init__(self):
        self.flow = FlowFieldAI()
        self.attr = AttractorAI()
        self.noise = NoiseAI()
    def step(self, x, y):
        fx, fy = self.flow.step(x, y)
        ax, ay = self.attr.step(x, y)
        nx, ny = self.noise.step(x, y)
        return (fx+ax+nx)/3, (fy+ay+ny)/3


# ============================================================
# SCRIPT-STYLE HANDWRITING ENGINE A–Z
# ============================================================

class HandwritingAI:
    def __init__(self):
        self.scale = 18

    def curve(self, pts):
        """Convert control points into smooth interpolated curve."""
        out = []
        for i in range(len(pts)-1):
            x1,y1 = pts[i]
            x2,y2 = pts[i+1]
            for t in [k/12 for k in range(13)]:
                out.append((x1 + (x2-x1)*t, y1 + (y2-y1)*t))
        return out

    # LETTER DEFINITIONS (script-style curves)
    # ------------------------------------------------------
    def A(self):
        s=self.scale
        pts=[(0,0),(s,2*s),(2*s,0),(s,1.1*s),(0.5*s,1.3*s)]
        return self.curve(pts)

    def B(self):
        s=self.scale
        pts=[(0,0),(0,2*s),(s,2*s),(1.4*s,1.5*s),(s,s),
             (1.3*s,0.5*s),(s,0)]
        return self.curve(pts)

    def C(self):
        s=self.scale
        pts=[(1.4*s*math.cos(math.radians(t)),
               1.4*s*math.sin(math.radians(t)))
            for t in range(20,200,5)]
        return pts

    def D(self):
        s=self.scale
        pts=[(0,0),(0,2*s),(s,2*s),(1.5*s,1.3*s),(s,0)]
        return self.curve(pts)

    def E(self):
        s=self.scale
        pts=[(1.5*s,2*s),(0,2*s),(0,0),(1.3*s,0)]
        return self.curve(pts)

    def F(self):
        s=self.scale
        pts=[(0,0),(0,2*s),(1.3*s,2*s),(0,2*s),(0,1.1*s),(1*s,1.1*s)]
        return self.curve(pts)

    def G(self):
        s=self.scale
        pts=[]
        for t in range(20,260,5):
            rad=math.radians(t)
            pts.append((1.4*s*math.cos(rad), 1.4*s*math.sin(rad)))
        pts.extend(self.curve([(s,0),(1.2*s,0.5*s)]))
        return pts

    def H(self):
        s=self.scale
        pts=[(0,0),(0,2*s),(0,s),(2*s,s),(2*s,2*s),(2*s,0)]
        return self.curve(pts)

    def I(self):
        s=self.scale
        return self.curve([(0,2*s),(s,2*s),(s,0),(0,0)])

    def J(self):
        s=self.scale
        return self.curve([(s,2*s),(s,0.4*s),(0.5*s,0),(0,0.6*s)])

    def K(self):
        s=self.scale
        pts=[(0,0),(0,2*s),(0.3*s,1.2*s),(1.3*s,2*s),
             (0.4*s,1.2*s),(1.3*s,0)]
        return self.curve(pts)

    def L(self):
        s=self.scale
        return self.curve([(0,2*s),(0,0),(1.5*s,0)])

    def M(self):
        s=self.scale
        pts=[(0,0),(0,2*s),(s,1.2*s),(2*s,2*s),(2*s,0)]
        return self.curve(pts)

    def N(self):
        s=self.scale
        pts=[(0,0),(0,2*s),(2*s,0),(2*s,2*s)]
        return self.curve(pts)

    def O(self):
        s=self.scale
        return [(1.4*s*math.cos(math.radians(t)),
                 1.4*s*math.sin(math.radians(t)))
                 for t in range(0,360,5)]

    def P(self):
        s=self.scale
        pts=[(0,0),(0,2*s),(s,2*s),(1.3*s,1.5*s),(s,1*s)]
        return self.curve(pts)

    def Q(self):
        s=self.scale
        pts=self.O()
        pts.extend(self.curve([(0.5*s,-0.2*s),(1.1*s,-1*s)]))
        return pts

    def R(self):
        s=self.scale
        pts=[(0,0),(0,2*s),(s,2*s),(1.3*s,1.4*s),
             (s,s),(1.5*s,0)]
        return self.curve(pts)

    def S(self):
        s=self.scale
        pts=[]
        for t in range(20,200,6):
            rad=math.radians(t)
            pts.append((1.3*s*math.cos(rad), 1.3*s*math.sin(rad)))
        for t in range(200,370,6):
            rad=math.radians(t)
            pts.append((1.3*s*math.cos(rad), 1.3*s*math.sin(rad)-s))
        return pts

    def T(self):
        s=self.scale
        pts=[(0,2*s),(2*s,2*s),(s,2*s),(s,0)]
        return self.curve(pts)

    def U(self):
        s=self.scale
        pts=[(s*math.cos(math.radians(t)),
               s*math.sin(math.radians(t)))
             for t in range(0,180,6)]
        pts.extend(self.curve([(s,2*s),(s,0)]))
        return pts

    def V(self):
        s=self.scale
        return self.curve([(0,2*s),(s,0),(2*s,2*s)])

    def W(self):
        s=self.scale
        return self.curve([(0,2*s),(0.7*s,0),(1.4*s,2*s),(2*s,0),(2.7*s,2*s)])

    def X(self):
        s=self.scale
        return self.curve([(0,2*s),(2*s,0),(s,1*s),(0,0),(2*s,2*s)])

    def Y(self):
        s=self.scale
        return self.curve([(0,2*s),(s,1*s),(2*s,2*s),(s,1*s),(s,0)])

    def Z(self):
        s=self.scale
        return self.curve([(0,2*s),(2*s,2*s),(0,0),(2*s,0)])

    # Dispatch
    def letter_points(self, ch):
        ch = ch.upper()
        if "A" <= ch <= "Z":
            return getattr(self, ch)()
        return []

    def text_to_points(self, text):
        cursor = 0
        all_pts = []
        for ch in text:
            pts = self.letter_points(ch)
            shifted = [(x+cursor, y) for (x,y) in pts]
            all_pts.extend(shifted)
            cursor += 50
        return all_pts


# ============================================================
# AI Brain Wrapper
# ============================================================

class AIBrain:
    def __init__(self):
        self.log = AILog()
        self.styles = {
            "flow": FlowFieldAI(),
            "attractor": AttractorAI(),
            "noise": NoiseAI(),
            "hybrid": HybridAI()
        }
        self.style = "flow"
        self.handwriting = HandwritingAI()

    def set_style(self, name):
        if name in self.styles:
            self.style = name
            self.log.write(f"Changed style to {name}")

    def get_next_move(self, x, y):
        dx, dy = self.styles[self.style].step(x, y)
        mag = math.sqrt(dx*dx + dy*dy) + 1e-6
        return dx/mag, dy/mag
