# main.py
import time
from collections import deque

from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.textinput import TextInput
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.graphics import Color, Line
from kivy.uix.popup import Popup
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.uix.screenmanager import ScreenManager, Screen

from ai_brain import AIBrain
from shape_templates import ShapeTemplates


class DrawingPad(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # Full history retained forever
        self.snake_path = []
        self.snake_pos = [Window.width//2, Window.height//2]

        self.snake_speed = 7
        self.template_queue = []
        self.auto_running = False
        self.pencil_active = False

        self.ai = AIBrain()

        with self.canvas:
            Color(0,1,0)
            self.snake_line = Line(points=[*self.snake_pos], width=2.5)

        Clock.schedule_interval(self.update, 1/60)

    # ------------------------------
    # BUTTON ACTIONS
    # ------------------------------

    def start_ai(self):
        self.auto_running = True
        self.pencil_active = True

    def stop_ai(self):
        self.auto_running = False
        self.template_queue.clear()
        self.pencil_active = False

    def clear_canvas(self):
        self.snake_path = []
        self.snake_pos = [Window.width//2, Window.height//2]
        self.snake_line.points = [*self.snake_pos]

    def save_image(self):
        filename = f"drawing_{int(time.time())}.png"
        self.export_to_png(filename)
        Popup(title="Saved",
              content=Label(text=f"Saved: {filename}"),
              size_hint=(0.4,0.3)).open()

    # ------------------------------
    # STYLE POPUP
    # ------------------------------

    def open_style_popup(self):
        if self.pencil_active: return

        layout = BoxLayout(orientation="vertical", spacing=5)
        for s in ["flow","attractor","noise","hybrid"]:
            b = Button(text=s.capitalize(), height=40)
            b.bind(on_release=lambda _,st=s:self.set_style(st))
            layout.add_widget(b)

        self._style_popup = Popup(title="Choose Style", content=layout,
                                  size_hint=(0.45,0.6))
        self._style_popup.open()

    def set_style(self, style):
        self.ai.set_style(style)
        self._style_popup.dismiss()

    # ------------------------------
    # SHAPES POPUP
    # ------------------------------

    def open_shape_popup(self):
        if self.pencil_active: return

        layout = BoxLayout(orientation="vertical", spacing=5)
        shapes = {
            "Circle":ShapeTemplates.circle_points(),
            "Square":ShapeTemplates.square_points(),
            "Triangle":ShapeTemplates.triangle_points(),
            "Star":ShapeTemplates.star_points(),
            "Spiral":ShapeTemplates.spiral_points(),
            "Heart":ShapeTemplates.heart_points(),
        }

        for name, pts in shapes.items():
            b = Button(text=name, height=40)
            b.bind(on_release=lambda _,p=pts:self.use_shape(p))
            layout.add_widget(b)

        self._shape_popup = Popup(title="Choose Shape", content=layout,
                                  size_hint=(0.45,0.7))
        self._shape_popup.open()

    def use_shape(self, pts):
        self.template_queue = [(x/6, y/6) for x,y in pts]
        self.pencil_active = True
        self._shape_popup.dismiss()

    # ------------------------------
    # TEXT POPUP
    # ------------------------------

    def open_text_popup(self):
        if self.pencil_active: return

        layout = BoxLayout(orientation="vertical", spacing=5)

        lbl = Label(text="Enter up to 10 letters:")
        txt = TextInput(text="", multiline=False, height=40, size_hint_y=None)
        btn = Button(text="Draw", height=40)

        btn.bind(on_release=lambda _:
                 self.use_text(txt.text[:10]))

        layout.add_widget(lbl)
        layout.add_widget(txt)
        layout.add_widget(btn)

        self._text_popup = Popup(title="Enter Text",
                                 content=layout,
                                 size_hint=(0.5,0.4))
        self._text_popup.open()

    def use_text(self, text):
        self._text_popup.dismiss()
        pts = self.ai.handwriting.text_to_points(text)
        self.template_queue = [(x/6,y/6) for x,y in pts]
        self.pencil_active = True

    # ------------------------------
    # MOVEMENT
    # ------------------------------

    def move_snake(self, dx, dy):
        x,y = self.snake_pos
        nx = max(5, min(x+dx, Window.width-5))
        ny = max(5, min(y+dy, Window.height-5))

        self.snake_pos = [nx, ny]
        self.snake_path.append(nx)
        self.snake_path.append(ny)
        self.snake_line.points = self.snake_path[:]

    def update(self, dt):

        # template animation
        if self.template_queue:
            dx, dy = self.template_queue.pop(0)
            self.move_snake(dx, dy)
            self.pencil_active = True
            return

        # auto mode
        if self.auto_running:
            dx, dy = self.ai.get_next_move(*self.snake_pos)
            self.move_snake(dx*self.snake_speed, dy*self.snake_speed)
            self.pencil_active = True
        else:
            self.pencil_active = False


class DrawingScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        root = BoxLayout(orientation="vertical")
        self.pad = DrawingPad()
        root.add_widget(self.pad)

        toolbar = BoxLayout(size_hint_y=0.12, spacing=5, padding=5)

        buttons = {
            "Start":("Start AI", self.pad.start_ai),
            "Stop":("Stop", self.pad.stop_ai),
            "Style":("Style", self.pad.open_style_popup),
            "Clear":("Clear", self.pad.clear_canvas),
            "Shapes":("Shapes", self.pad.open_shape_popup),
            "Text":("Text", self.pad.open_text_popup),
            "Save":("Save Image", self.pad.save_image),
        }

        self.btn_refs = {}

        for key,(txt,func) in buttons.items():
            b = Button(text=txt)
            b.bind(on_release=lambda _,f=func:f())
            toolbar.add_widget(b)
            self.btn_refs[key] = b

        root.add_widget(toolbar)
        self.add_widget(root)

        Clock.schedule_interval(self.update_buttons, 1/30)

    def update_buttons(self, dt):
        active = self.pad.pencil_active
        for name, b in self.btn_refs.items():
            if name == "Stop":
                b.disabled = False
            else:
                b.disabled = active


class SnakeApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(DrawingScreen(name="draw"))
        return sm


if __name__ == "__main__":
    SnakeApp().run()
