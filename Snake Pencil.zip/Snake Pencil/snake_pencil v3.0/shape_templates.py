# shape_templates.py
import math

class ShapeTemplates:

    @staticmethod
    def circle_points():
        pts=[]
        for t in range(0,360,5):
            r=80
            x=r*math.cos(math.radians(t))
            y=r*math.sin(math.radians(t))
            pts.append((x,y))
        return pts

    @staticmethod
    def square_points():
        return [
            (-80,-80),(80,-80),(80,80),(-80,80),(-80,-80)
        ]

    @staticmethod
    def triangle_points():
        return [
            (0,90), (80,-60), (-80,-60), (0,90)
        ]

    @staticmethod
    def star_points():
        pts=[]
        r1=90
        r2=40
        for t in range(0,360,36):
            x=r1*math.cos(math.radians(t))
            y=r1*math.sin(math.radians(t))
            pts.append((x,y))
            x=r2*math.cos(math.radians(t+18))
            y=r2*math.sin(math.radians(t+18))
            pts.append((x,y))
        return pts

    @staticmethod
    def spiral_points():
        pts=[]
        for i in range(200):
            angle = i * 0.2
            r = i * 0.8
            x = r * math.cos(angle)
            y = r * math.sin(angle)
            pts.append((x,y))
        return pts

    @staticmethod
    def heart_points():
        pts=[]
        for t in range(0,360,5):
            rad = math.radians(t)
            x = 16*math.sin(rad)**3
            y = 13*math.cos(rad) - 5*math.cos(2*rad) - 2*math.cos(3*rad) - math.cos(4*rad)
            pts.append((x*6, y*6))
        return pts
